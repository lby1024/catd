"use strict";(self.webpackChunkcatd=self.webpackChunkcatd||[]).push([[1904],{71183:function(u,t,n){n.r(t),n.d(t,{demos:function(){return o}});var d=n(62435),o={}},15561:function(u,t,n){n.r(t),n.d(t,{demos:function(){return o}});var d=n(62435),o={}},37523:function(u,t,n){n.r(t),n.d(t,{texts:function(){return d}});const d=[{value:`npm install catd --save
`,paraId:0,tocIndex:0},{value:`import { Icon } from 'catd';

export const App = () => <Icon name="add" size="30" />;
`,paraId:1,tocIndex:1}]},2687:function(u,t,n){n.r(t),n.d(t,{texts:function(){return d}});const d=[]}}]);
