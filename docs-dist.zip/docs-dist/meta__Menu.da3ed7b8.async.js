"use strict";(self.webpackChunkcatd=self.webpackChunkcatd||[]).push([[9501],{88565:function(m,t,n){n.r(t),n.d(t,{demos:function(){return v}});var c=n(17061),u=n.n(c),p=n(17156),s=n.n(p),d=n(62435),v={"src-menu-demo-demo01":{component:d.memo(d.lazy(function(){return n.e(2433).then(n.bind(n,10079))})),asset:{type:"BLOCK",id:"src-menu-demo-demo01",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:n(61080).Z},catd:{type:"NPM",value:"1.0.5"}},entry:"index.tsx"},context:{catd:n(31081)},renderOpts:{compile:function(){var o=s()(u()().mark(function r(){var a,l=arguments;return u()().wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,n.e(7335).then(n.bind(n,37335));case 2:return e.abrupt("return",(a=e.sent).default.apply(a,l));case 3:case"end":return e.stop()}},r)}));function I(){return o.apply(this,arguments)}return I}()}},"src-menu-demo-demo02":{component:d.memo(d.lazy(function(){return n.e(2433).then(n.bind(n,64552))})),asset:{type:"BLOCK",id:"src-menu-demo-demo02",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:n(5801).Z},catd:{type:"NPM",value:"1.0.5"}},entry:"index.tsx"},context:{catd:n(31081)},renderOpts:{compile:function(){var o=s()(u()().mark(function r(){var a,l=arguments;return u()().wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,n.e(7335).then(n.bind(n,37335));case 2:return e.abrupt("return",(a=e.sent).default.apply(a,l));case 3:case"end":return e.stop()}},r)}));function I(){return o.apply(this,arguments)}return I}()}},"src-menu-demo-demo03":{component:d.memo(d.lazy(function(){return n.e(2433).then(n.bind(n,315))})),asset:{type:"BLOCK",id:"src-menu-demo-demo03",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:n(19388).Z},catd:{type:"NPM",value:"1.0.5"}},entry:"index.tsx"},context:{catd:n(31081)},renderOpts:{compile:function(){var o=s()(u()().mark(function r(){var a,l=arguments;return u()().wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,n.e(7335).then(n.bind(n,37335));case 2:return e.abrupt("return",(a=e.sent).default.apply(a,l));case 3:case"end":return e.stop()}},r)}));function I(){return o.apply(this,arguments)}return I}()}}}},77861:function(m,t,n){n.r(t),n.d(t,{texts:function(){return c}});const c=[{value:`

  
  
  `,paraId:0},{value:`
  `,paraId:1,tocIndex:6},{value:`
    `,paraId:1,tocIndex:6},{value:"\u5C5E\u6027\u540D",paraId:1,tocIndex:6},{value:`
    `,paraId:1,tocIndex:6},{value:"\u63CF\u8FF0",paraId:1,tocIndex:6},{value:`
    `,paraId:1,tocIndex:6},{value:"\u7C7B\u578B",paraId:1,tocIndex:6},{value:`
    `,paraId:1,tocIndex:6},{value:"\u9ED8\u8BA4\u503C",paraId:1,tocIndex:6},{value:`
  `,paraId:1,tocIndex:6},{value:`
    `,paraId:1,tocIndex:6},{value:"name",paraId:1,tocIndex:6},{value:`
    `,paraId:1,tocIndex:6},{value:"item \u7684\u552F\u4E00\u6807\u5FD7",paraId:1,tocIndex:6},{value:`
    `,paraId:1,tocIndex:6},{value:"string",paraId:1,tocIndex:6},{value:`
    `,paraId:1,tocIndex:6},{value:`
  `,paraId:1,tocIndex:6},{value:`
    `,paraId:1,tocIndex:6},{value:"title",paraId:1,tocIndex:6},{value:`
    `,paraId:1,tocIndex:6},{value:"\u83DC\u5355\u9879\u6807\u9898",paraId:1,tocIndex:6},{value:`
    `,paraId:1,tocIndex:6},{value:"string",paraId:1,tocIndex:6},{value:`
    `,paraId:1,tocIndex:6},{value:`
  `,paraId:1,tocIndex:6},{value:`
    `,paraId:1,tocIndex:6},{value:"mode",paraId:1,tocIndex:6},{value:`
    `,paraId:1,tocIndex:6},{value:"\u83DC\u5355\u7C7B\u578B\uFF0C\u73B0\u5728\u652F\u6301\u5782\u76F4\u3001\u6C34\u5E73\u3001\u548C\u5185\u5D4C\u6A21\u5F0F\u4E09\u79CD",paraId:1,tocIndex:6},{value:`
    `,paraId:1,tocIndex:6},{value:"'inline' | 'vertical' | 'horizon'",paraId:1,tocIndex:6},{value:`
    `,paraId:1,tocIndex:6},{value:"'inline'",paraId:1,tocIndex:6},{value:`
  `,paraId:1,tocIndex:6},{value:`

  `,paraId:0},{value:`
  `,paraId:2,tocIndex:7},{value:`
    `,paraId:2,tocIndex:7},{value:"\u5C5E\u6027\u540D",paraId:2,tocIndex:7},{value:`
    `,paraId:2,tocIndex:7},{value:"\u63CF\u8FF0",paraId:2,tocIndex:7},{value:`
    `,paraId:2,tocIndex:7},{value:"\u7C7B\u578B",paraId:2,tocIndex:7},{value:`
    `,paraId:2,tocIndex:7},{value:"\u9ED8\u8BA4\u503C",paraId:2,tocIndex:7},{value:`
  `,paraId:2,tocIndex:7},{value:`
    `,paraId:2,tocIndex:7},{value:"name",paraId:2,tocIndex:7},{value:`
    `,paraId:2,tocIndex:7},{value:"item \u7684\u552F\u4E00\u6807\u5FD7",paraId:2,tocIndex:7},{value:`
    `,paraId:2,tocIndex:7},{value:"string",paraId:2,tocIndex:7},{value:`
    `,paraId:2,tocIndex:7},{value:`
  `,paraId:2,tocIndex:7}]},61080:function(m,t){t.Z=`import { Menu } from 'catd';

const App = () => {
  function onSelect(res: any) {
    console.log(res);
  }

  return (
    <Menu style={{ width: 'auto' }} onSelect={onSelect} mode="horizon">
      <Menu.Item>\u5E03\u5C40</Menu.Item>
      <Menu.Sub title="Navigation Two - Submenu">
        <Menu.Item>Navigation One</Menu.Item>
        <Menu.Item>Navigation Two</Menu.Item>
        <Menu.Sub title="Submenu">
          <Menu.Item>Navigation One</Menu.Item>
          <Menu.Item>Navigation Two</Menu.Item>
        </Menu.Sub>
      </Menu.Sub>
      <Menu.Sub title="\u901A\u7528">
        <Menu.Item>button</Menu.Item>
        <Menu.Item>icon</Menu.Item>
      </Menu.Sub>
      <Menu.Item>\u5176\u4ED6</Menu.Item>
    </Menu>
  );
};

export default App;
`},5801:function(m,t){t.Z=`import { Menu } from 'catd';

const App = () => {
  function onSelect(res: any) {
    console.log(res);
  }

  return (
    <Menu style={{ width: 250 }} onSelect={onSelect} mode="inline">
      <Menu.Item>\u5E03\u5C40</Menu.Item>
      <Menu.Sub title="Navigation Two - Submenu">
        <Menu.Item>Navigation One</Menu.Item>
        <Menu.Item>Navigation Two</Menu.Item>
        <Menu.Sub title="Submenu">
          <Menu.Item>Navigation One</Menu.Item>
          <Menu.Item>Navigation Two</Menu.Item>
        </Menu.Sub>
      </Menu.Sub>
      <Menu.Sub title="\u901A\u7528">
        <Menu.Item>button</Menu.Item>
        <Menu.Item>icon</Menu.Item>
      </Menu.Sub>
      <Menu.Item>\u5176\u4ED6</Menu.Item>
    </Menu>
  );
};

export default App;
`},19388:function(m,t){t.Z=`import { Menu } from 'catd';

const App = () => {
  function onSelect(res: any) {
    console.log(res);
  }

  return (
    <Menu style={{ width: 250 }} onSelect={onSelect} mode="vertical">
      <Menu.Item>\u5E03\u5C40</Menu.Item>
      <Menu.Sub title="Navigation Two - Submenu">
        <Menu.Item>Navigation One</Menu.Item>
        <Menu.Item>Navigation Two</Menu.Item>
        <Menu.Sub title="Submenu">
          <Menu.Item>Navigation One</Menu.Item>
          <Menu.Item>Navigation Two</Menu.Item>
        </Menu.Sub>
      </Menu.Sub>
      <Menu.Sub title="\u901A\u7528">
        <Menu.Item>button</Menu.Item>
        <Menu.Item>icon</Menu.Item>
      </Menu.Sub>
      <Menu.Item>\u5176\u4ED6</Menu.Item>
    </Menu>
  );
};

export default App;
`}}]);
