"use strict";(self.webpackChunkcatd=self.webpackChunkcatd||[]).push([[9461],{27820:function(c,t,n){n.r(t),n.d(t,{demos:function(){return i}});var I=n(17061),d=n.n(I),v=n(17156),p=n.n(v),o=n(62435),i={"src-button-demo-demo01":{component:o.memo(o.lazy(function(){return n.e(2433).then(n.bind(n,84651))})),asset:{type:"BLOCK",id:"src-button-demo-demo01",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:n(83355).Z},catd:{type:"NPM",value:"1.0.5"}},entry:"index.tsx"},context:{catd:n(31081)},renderOpts:{compile:function(){var r=p()(d()().mark(function l(){var a,s=arguments;return d()().wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,n.e(7335).then(n.bind(n,37335));case 2:return e.abrupt("return",(a=e.sent).default.apply(a,s));case 3:case"end":return e.stop()}},l)}));function u(){return r.apply(this,arguments)}return u}()}},"src-button-demo-demo02":{component:o.memo(o.lazy(function(){return n.e(2433).then(n.bind(n,87491))})),asset:{type:"BLOCK",id:"src-button-demo-demo02",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:n(24513).Z},catd:{type:"NPM",value:"1.0.5"}},entry:"index.tsx"},context:{catd:n(31081)},renderOpts:{compile:function(){var r=p()(d()().mark(function l(){var a,s=arguments;return d()().wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,n.e(7335).then(n.bind(n,37335));case 2:return e.abrupt("return",(a=e.sent).default.apply(a,s));case 3:case"end":return e.stop()}},l)}));function u(){return r.apply(this,arguments)}return u}()}},"src-button-demo-demo03":{component:o.memo(o.lazy(function(){return n.e(2433).then(n.bind(n,90752))})),asset:{type:"BLOCK",id:"src-button-demo-demo03",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:n(57471).Z},catd:{type:"NPM",value:"1.0.5"}},entry:"index.tsx"},context:{catd:n(31081)},renderOpts:{compile:function(){var r=p()(d()().mark(function l(){var a,s=arguments;return d()().wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,n.e(7335).then(n.bind(n,37335));case 2:return e.abrupt("return",(a=e.sent).default.apply(a,s));case 3:case"end":return e.stop()}},l)}));function u(){return r.apply(this,arguments)}return u}()}}}},66565:function(c,t,n){n.r(t),n.d(t,{texts:function(){return I}});const I=[{value:`

  
  
  
  `,paraId:0},{value:`
  `,paraId:1,tocIndex:3},{value:`
    `,paraId:1,tocIndex:3},{value:"\u5C5E\u6027\u540D",paraId:1,tocIndex:3},{value:`
    `,paraId:1,tocIndex:3},{value:"\u63CF\u8FF0",paraId:1,tocIndex:3},{value:`
    `,paraId:1,tocIndex:3},{value:"\u7C7B\u578B",paraId:1,tocIndex:3},{value:`
    `,paraId:1,tocIndex:3},{value:"\u9ED8\u8BA4\u503C",paraId:1,tocIndex:3},{value:`
  `,paraId:1,tocIndex:3},{value:`
    `,paraId:1,tocIndex:3},{value:"disabled",paraId:1,tocIndex:3},{value:`
    `,paraId:1,tocIndex:3},{value:"\u662F\u5426\u53EF\u7528",paraId:1,tocIndex:3},{value:`
    `,paraId:1,tocIndex:3},{value:"boolean",paraId:1,tocIndex:3},{value:`
    `,paraId:1,tocIndex:3},{value:"false",paraId:1,tocIndex:3},{value:`
  `,paraId:1,tocIndex:3},{value:`
    `,paraId:1,tocIndex:3},{value:"size",paraId:1,tocIndex:3},{value:`
    `,paraId:1,tocIndex:3},{value:"\u5C3A\u5BF8",paraId:1,tocIndex:3},{value:`
    `,paraId:1,tocIndex:3},{value:"'lg' | 'sm' | 'md'",paraId:1,tocIndex:3},{value:`
    `,paraId:1,tocIndex:3},{value:"md",paraId:1,tocIndex:3},{value:`
  `,paraId:1,tocIndex:3},{value:`
    `,paraId:1,tocIndex:3},{value:"btnType",paraId:1,tocIndex:3},{value:`
    `,paraId:1,tocIndex:3},{value:"\u6309\u94AE\u7C7B\u578B",paraId:1,tocIndex:3},{value:`
    `,paraId:1,tocIndex:3},{value:"'primary' | 'default' | 'danger' | 'link'",paraId:1,tocIndex:3},{value:`
    `,paraId:1,tocIndex:3},{value:"'default'",paraId:1,tocIndex:3},{value:`
  `,paraId:1,tocIndex:3},{value:`
    `,paraId:1,tocIndex:3},{value:"loading",paraId:1,tocIndex:3},{value:`
    `,paraId:1,tocIndex:3},{value:"\u663E\u793A\u52A0\u8F7D\u52A8\u753B",paraId:1,tocIndex:3},{value:`
    `,paraId:1,tocIndex:3},{value:"boolen",paraId:1,tocIndex:3},{value:`
    `,paraId:1,tocIndex:3},{value:"false",paraId:1,tocIndex:3},{value:`
  `,paraId:1,tocIndex:3}]},83355:function(c,t){t.Z=`import { Button } from 'catd';

export default () => (
  <div>
    <Button className="aaa" btnType="default">
      default
    </Button>
    <Button btnType="primary">pramiry</Button>
    <Button btnType="danger">danger</Button>
    <Button btnType="link" href="http://www.baidu.com">
      link
    </Button>
  </div>
);`},24513:function(c,t){t.Z=`import { Button } from 'catd';

export default () => (
  <>
    <Button btnType='primary' size="lg">
      large
    </Button>
    <Button btnType="danger">default</Button>
    <Button btnType="default" size="sm">
      small
    </Button>
  </>
);`},57471:function(c,t){t.Z=`import { Button } from 'catd';

export default () => (
  <>
    <Button btnType="primary" loading>
      loading...
    </Button>
    <Button btnType="danger" disabled>
      disable
    </Button>
    <Button btnType="link" href="http://www.baidu.com" disabled>
      link disable
    </Button>
  </>
);`}}]);
