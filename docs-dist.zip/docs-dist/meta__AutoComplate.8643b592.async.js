"use strict";(self.webpackChunkcatd=self.webpackChunkcatd||[]).push([[5678],{23480:function(s,a,n){n.r(a),n.d(a,{demos:function(){return I}});var p=n(17061),r=n.n(p),c=n(17156),u=n.n(c),o=n(62435),I={"src-auto-complate-demo-demo":{component:o.memo(o.lazy(function(){return n.e(2433).then(n.bind(n,70732))})),asset:{type:"BLOCK",id:"src-auto-complate-demo-demo",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:n(35163).Z},catd:{type:"NPM",value:"1.0.5"},"./jsonp.ts":{type:"FILE",value:n(3112).Z}},entry:"index.tsx"},context:{catd:n(31081),"./jsonp.ts":n(45607)},renderOpts:{compile:function(){var t=u()(r()().mark(function m(){var l,i=arguments;return r()().wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,n.e(7335).then(n.bind(n,37335));case 2:return e.abrupt("return",(l=e.sent).default.apply(l,i));case 3:case"end":return e.stop()}},m)}));function d(){return t.apply(this,arguments)}return d}()}},"src-auto-complate-demo-demo02":{component:o.memo(o.lazy(function(){return n.e(2433).then(n.bind(n,32982))})),asset:{type:"BLOCK",id:"src-auto-complate-demo-demo02",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:n(22072).Z},catd:{type:"NPM",value:"1.0.5"}},entry:"index.tsx"},context:{catd:n(31081)},renderOpts:{compile:function(){var t=u()(r()().mark(function m(){var l,i=arguments;return r()().wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,n.e(7335).then(n.bind(n,37335));case 2:return e.abrupt("return",(l=e.sent).default.apply(l,i));case 3:case"end":return e.stop()}},m)}));function d(){return t.apply(this,arguments)}return d}()}},"src-auto-complate-demo-demo03":{component:o.memo(o.lazy(function(){return n.e(2433).then(n.bind(n,4339))})),asset:{type:"BLOCK",id:"src-auto-complate-demo-demo03",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:n(93330).Z},"styled-components":{type:"NPM",value:"5.3.11"},catd:{type:"NPM",value:"1.0.5"},"./jsonp.ts":{type:"FILE",value:n(3112).Z}},entry:"index.tsx"},context:{"styled-components":n(19521),catd:n(31081),"./jsonp.ts":n(45607)},renderOpts:{compile:function(){var t=u()(r()().mark(function m(){var l,i=arguments;return r()().wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,n.e(7335).then(n.bind(n,37335));case 2:return e.abrupt("return",(l=e.sent).default.apply(l,i));case 3:case"end":return e.stop()}},m)}));function d(){return t.apply(this,arguments)}return d}()}}}},45607:function(s,a,n){n.r(a),n.d(a,{jsonp:function(){return r}});function p(c){var u=c.url,o=c.params,I=c.cbName,t=[];for(var d in o)t.push("".concat(d,"=").concat(o[d]));return"".concat(u,"?").concat(t.join("&"),"&cb=").concat(I)}function r(c){var u=c.cbName;return new Promise(function(o){var I=p(c),t=document.createElement("script");t.src=I,document.body.appendChild(t),window[u]=function(d){o(d),document.body.removeChild(t)}})}},92649:function(s,a,n){n.r(a),n.d(a,{texts:function(){return p}});const p=[{value:`

  
  
  
  
  
  
  
  
`,paraId:0},{value:`
  `,paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"\u5C5E\u6027\u540D",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"\u63CF\u8FF0",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"\u7C7B\u578B",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"\u9ED8\u8BA4\u503C",paraId:1,tocIndex:4},{value:`
  `,paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"size",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"\u5927\u5C0F",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"'large' | 'small' | 'default'",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"default",paraId:1,tocIndex:4},{value:`
  `,paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"addOnBefore",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"\u5C3A\u5BF8\u5E26\u6807\u7B7E\u7684 input\uFF0C\u8BBE\u7F6E\u524D\u7F6E\u6807\u7B7E",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"string | ReactElement",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:`
  `,paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"addOnAfter",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"\u5C3A\u5BF8\u5E26\u6807\u7B7E\u7684 input\uFF0C\u8BBE\u7F6E\u540E\u7F6E\u6807\u7B7E",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"string | ReactElement",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:`
  `,paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"prefix",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"\u5E26\u6709\u524D\u7F00\u56FE\u6807\u7684 input",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"string | ReactElement",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:`
  `,paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"suffix",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"\u5E26\u6709\u540E\u7F00\u56FE\u6807\u7684 input",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"string | ReactElement",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:`
  `,paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"onSearch",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"\u641C\u7D22\u8865\u5168\u9879\u7684\u65F6\u5019\u8C03\u7528",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"function(value)",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:`
  `,paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"onSelect",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"\u88AB\u9009\u4E2D\u65F6\u8C03\u7528\uFF0C\u53C2\u6570\u4E3A\u9009\u4E2D\u9879\u7684 value \u503C	",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"function(item)",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:`
  `,paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"renderItem",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"\u81EA\u5B9A\u4E49item\u6837\u5F0F",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"item => ReactNode",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:`
  `,paraId:1,tocIndex:4}]},35163:function(s,a){a.Z=`import { AutoComplete, Icon } from 'catd';
import { jsonp } from './jsonp';

const App = () => {
  async function onSearch(wd: string) {
    let res: any = await jsonp({
      url: 'https://sp0.baidu.com/5a1Fazu8AA54nxGko9WTAnF6hhy/su',
      params: { wd },
      cbName: 'show',
    });
    res = res.s.map((value: string, index: number) => ({ value, index }));

    return res;
  }

  return (
    <AutoComplete
      onSearch={onSearch}
      style={{ width: 300 }}
      prefix={<Icon name="search" />}
      placeholder='search' />
  );
};

export default App;


`},22072:function(s,a){a.Z=`import { AutoComplete } from 'catd';

const App = () => {
  function onSearch(wd: string) {
    const emails = ['qq', 'gmail', '163'];
    return emails.map((v) => ({ value: \`\${wd}@\${v}.com\` }));
  }

  return <AutoComplete onSearch={onSearch} style={{ width: 300 }} placeholder='\u8BF7\u8F93\u5165\u90AE\u7BB1' />;
};

export default App;
`},93330:function(s,a){a.Z=`import styled from 'styled-components';
import { AutoComplete, Icon } from 'catd';
import { AutoItemType } from 'src/AutoComplate/AutoComplete';
import { jsonp } from './jsonp';

type Item = {
  value: string;
  results?: number;
};

const ListItem = styled.div\`
  line-height: 2em;
  display: flex;
  justify-content: space-between;
  span {
    color: #999;
  }
\`;

const App = () => {
  async function onSearch(wd: string) {
    let res: any = await jsonp({
      url: 'https://sp0.baidu.com/5a1Fazu8AA54nxGko9WTAnF6hhy/su',
      params: { wd },
      cbName: 'show',
    });
    function radom() {
      let n = Math.random() * 100;
      return Math.floor(n);
    }
    res = res.s.map((value: string) => ({ value, results: radom() }));

    return res;
  }

  const renderItem = (item: AutoItemType<Item>) => (
    <ListItem>
      {item.value}
      <span>{item.results} result</span>
    </ListItem>
  );

  return (
    <AutoComplete
      onSearch={onSearch}
      style={{ width: 300 }}
      renderItem={renderItem}
      addOnAfter={<Icon name="search" />}
      placeholder='search'
    />
  );
};

export default App;

`},3112:function(s,a){a.Z=`import { Obj } from 'src/tools/type';

type JsonpType = {
  url: string;
  params: Obj;
  cbName: string;
};

function getSrc(option: JsonpType) {
  const { url, params, cbName } = option;
  let list = [];
  // eslint-disable-next-line guard-for-in
  for (let key in params) {
    list.push(\`\${key}=\${params[key]}\`);
  }
  return \`\${url}?\${list.join('&')}&cb=\${cbName}\`;
}

export function jsonp(option: JsonpType) {
  const { cbName } = option;
  return new Promise((resolve) => {
    let src = getSrc(option)
    let script = document.createElement('script');
    script.src = src;
    document.body.appendChild(script);
    // @ts-ignore
    window[cbName] = function (data: any) {
      resolve(data);
      document.body.removeChild(script);
    };
  });
}`}}]);
