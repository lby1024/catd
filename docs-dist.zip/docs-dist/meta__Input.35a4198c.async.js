"use strict";(self.webpackChunkcatd=self.webpackChunkcatd||[]).push([[1808],{61362:function(c,a,n){n.r(a),n.d(a,{demos:function(){return v}});var p=n(17061),d=n.n(p),i=n(17156),I=n.n(i),r=n(62435),v={"src-input-demo-demo":{component:r.memo(r.lazy(function(){return n.e(2433).then(n.bind(n,22585))})),asset:{type:"BLOCK",id:"src-input-demo-demo",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:n(18462).Z},catd:{type:"NPM",value:"1.0.5"}},entry:"index.tsx"},context:{catd:n(31081)},renderOpts:{compile:function(){var o=I()(d()().mark(function u(){var t,s=arguments;return d()().wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,n.e(7335).then(n.bind(n,37335));case 2:return e.abrupt("return",(t=e.sent).default.apply(t,s));case 3:case"end":return e.stop()}},u)}));function l(){return o.apply(this,arguments)}return l}()}},"src-input-demo-demo02":{component:r.memo(r.lazy(function(){return n.e(2433).then(n.bind(n,79674))})),asset:{type:"BLOCK",id:"src-input-demo-demo02",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:n(20908).Z},catd:{type:"NPM",value:"1.0.5"}},entry:"index.tsx"},context:{catd:n(31081)},renderOpts:{compile:function(){var o=I()(d()().mark(function u(){var t,s=arguments;return d()().wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,n.e(7335).then(n.bind(n,37335));case 2:return e.abrupt("return",(t=e.sent).default.apply(t,s));case 3:case"end":return e.stop()}},u)}));function l(){return o.apply(this,arguments)}return l}()}},"src-input-demo-demo03":{component:r.memo(r.lazy(function(){return n.e(2433).then(n.bind(n,79718))})),asset:{type:"BLOCK",id:"src-input-demo-demo03",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:n(2207).Z},catd:{type:"NPM",value:"1.0.5"}},entry:"index.tsx"},context:{catd:n(31081)},renderOpts:{compile:function(){var o=I()(d()().mark(function u(){var t,s=arguments;return d()().wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,n.e(7335).then(n.bind(n,37335));case 2:return e.abrupt("return",(t=e.sent).default.apply(t,s));case 3:case"end":return e.stop()}},u)}));function l(){return o.apply(this,arguments)}return l}()}}}},8983:function(c,a,n){n.r(a),n.d(a,{texts:function(){return p}});const p=[{value:`

  
  
  
  
  `,paraId:0},{value:`
  `,paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"\u5C5E\u6027\u540D",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"\u63CF\u8FF0",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"\u7C7B\u578B",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"\u9ED8\u8BA4\u503C",paraId:1,tocIndex:4},{value:`
  `,paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"size",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"\u5927\u5C0F",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"'large' | 'small' | 'default'",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"default",paraId:1,tocIndex:4},{value:`
  `,paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"addOnBefore",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"\u5C3A\u5BF8\u5E26\u6807\u7B7E\u7684 input\uFF0C\u8BBE\u7F6E\u524D\u7F6E\u6807\u7B7E",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"string | ReactElement",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:`
  `,paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"addOnAfter",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"\u5C3A\u5BF8\u5E26\u6807\u7B7E\u7684 input\uFF0C\u8BBE\u7F6E\u540E\u7F6E\u6807\u7B7E",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"string | ReactElement",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:`
  `,paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"prefix",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"\u5E26\u6709\u524D\u7F00\u56FE\u6807\u7684 input",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"string | ReactElement",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:`
  `,paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"suffix",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"\u5E26\u6709\u540E\u7F00\u56FE\u6807\u7684 input",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:"string | ReactElement",paraId:1,tocIndex:4},{value:`
    `,paraId:1,tocIndex:4},{value:`
  `,paraId:1,tocIndex:4}]},18462:function(c,a){a.Z=`import { CSSProperties } from 'react';
import { Input } from 'catd';

const style: CSSProperties = { width: 150 };
const App = () => {
  return <Input placeholder="base use" style={style} />;
};

export default App;
`},20908:function(c,a){a.Z=`import { CSSProperties } from 'react';
import { Input, Icon } from 'catd';

const style: CSSProperties = { width: 300 };

const App = () => {
  return (
    <>
      <Input addOnBefore="http://" addOnAfter=".com" defaultValue="catd" style={style} />
      <br />
      <br />
      <Input
        addOnBefore="https://"
        addOnAfter={<Icon name="search" />}
        defaultValue="catd"
        maxLength={10}
        style={style}
      />
      <br />
      <br />
      <Input
        style={style}
        suffix={<Icon name="mic" />}
        addOnAfter={<Icon name="search" />}
        placeholder="placeholder..."
      />
      <br />
      <br />
      <Input prefix="http://" defaultValue="catd" suffix=".com" style={style} />
      <br />
      <br />
      <Input
        prefix={<Icon name="RectangleCopy1" size="21" />}
        placeholder="user name"
        suffix="x"
        style={style}
      />
    </>
  );
};

export default App;
`},2207:function(c,a){a.Z=`import { CSSProperties } from 'react';
import { Input, Icon } from 'catd';

const style: CSSProperties = { width: 300 };

const App = () => {
  return (
    <>
      <Input prefix={<Icon name="search" />} placeholder="search..." size="large" style={style} />
      <br />
      <br />
      <Input prefix={<Icon name="search" />} placeholder="search..." style={style} />
      <br />
      <br />
      <Input prefix={<Icon name="search" />} placeholder="search..." size="small" style={style} />
    </>
  );
};

export default App;
`}}]);
